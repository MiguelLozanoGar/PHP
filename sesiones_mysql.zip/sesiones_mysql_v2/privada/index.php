<?php
/*ejemplo de auth de usuarios usando sesiones*/
session_start();
if(isset($_SESSION['token']))
{
    echo("<h2>Zona privado</h2>");
}
else{
    header('location:../auth/login.php');
}

