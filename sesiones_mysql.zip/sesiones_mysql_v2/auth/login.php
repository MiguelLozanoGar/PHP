<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Login de usuario</h2>
    <form action="" method="post">
        <p>Correo: <input type="email" name="correo" required></p>
        <p>Contraseña: <input type="password" name="password" required></p>
      
        <p><input type="submit" value="Acceder" name='dato'></p>
    </form>

    <?php
    if(isset($_POST['dato'])){
        $correo=$_POST['correo'];
        $password=$_POST['password'];
        $conn=new PDO("mysql:host=localhost;port=3306;dbname=test","root","");
        $consulta="select * from usuarios";
        $resultado=$conn->query($consulta); 
        while($row=$resultado->fetch()) {
           if($row['correo']==$correo and $row['contraseña']==$password){
           echo "usuario ok";
           session_start();
           $_SESSION['token']=session_id();
           echo "<br>";
           echo($_SESSION['token']);
           echo "<br>";
           echo('<a href="../privada/index.php">Ir a privado</a>');
            break;
           }
           
        } 
    }//icerra if isset post
    ?>
</body>
</html>