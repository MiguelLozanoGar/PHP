<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Alta  de nuevo usuario</h2>
    <form action="" method="post">
        <p>Correo: <input type="email" name="correo" required></p>
        <p>Contraseña: <input type="password" name="password" required></p>
        <p>Repetir contraseña: <input type="password" name="password2" required></p>
        <p><input type="checkbox" name="cb">Acepto condiciones</p>
        <p><input type="submit" value="Registro" name='dato'></p>
    </form>

    <?php
    if(isset($_POST['dato'])){
        $correo=$_POST['correo'];
        $password=$_POST['password'];
        $password2=$_POST['password2'];
        if($password==$password2){
            $conn=new PDO("mysql:host=localhost;port=3306;dbname=test","root","");
       /*$consulta="INSERT INTO `usuarios` (`id`, `correo`, `contraseña`, `fecha`) 
        VALUES (NULL,'".$correo."', '".$password."', NOW());";*/
        $consulta="call sp_add('".$correo."','".$password."')";
         $conn->query($consulta);
        header('location:login.php');
        }//cierra comprobación de password
        else{
            echo("<p>Contraseñas no coinciden</p>");
        }
    }//icerra if isset post
    ?>
</body>
</html>