<?php
echo("<h2>Zona pública</h2>");
echo("<a href='verproductos.php'>Consultar productos</a>");