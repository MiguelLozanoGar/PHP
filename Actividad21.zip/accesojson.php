<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar JSON</title>
</head>
<body>
    <h2>Gestionar JSON</h2>
    <a href="https://code.tutsplus.com/es/tutorials/how-to-parse-json-in-php--cms-36994"></a>
<?php
$archivo_json=file_get_contents(archivos/products.json);
$decoded_json = json_decode($archivo_json, true);
productos=$decoded_json['procucts'];

foreach($productos as $producto)
    echo "<p>".$prducto['title']
?>
</body>
</html>