<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Gestionar archivos</h2>
    <li><a href="accesotxt.php">Gestionar archivos de textos</a></li>
    <li><a href="accesojson.php">Gestionar archivos de JSON</a></li>
    <li><a href="accesoxml.php">Gestionar archivos de XML</a></li>
    <li><a href="ejercicioaccesotxt.php">Ejercicio archivos de textos</a></li>
    <li><a href="ejercicioaccesojson.php">Ejercicio archivos de JSON</a></li>
    <li><a href="ejercicioaccesoxml.php">Ejercicio archivos de XML</a></li>
    <li><a href="getapi.php">Consumir API</a></li>
    <li><a href="practicaapi.php">Practica consumo API</a></li>
</body>
</html>