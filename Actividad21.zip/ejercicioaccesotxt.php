<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Consultar y enviar sugerencias</h2>
    <p>Diseñar un formulario que permita escribir un comentario</p>
    <p>Al pulsar el botón enviar, se guarda el comentario en un archivo de texto</p>
    <p>Automáticamente, se muestra el contenido del archivo de comentarios</p>
    <p>Añadir en cada nuevo comentario, la fecha y la hora</p>

<?php
if (isset($_POST['submit'])){
    $comentario=$_POST['comentario'];
    $fecha=date("d-m-Y H:i:s");

    $file=fopen("comentarios.txt", "a");
    fwrite($file, $fecha." - ".$comentario."\n");
    fclose($file);
    }

  $comentarios = file("comentarios.txt");
?>

<form method="post">
  <label for="comentario">Escribe tu comentario:</label><br>
  <textarea name="comentario" rows="5" cols="40"></textarea><br>
  <input type="submit" name="submit" value="Enviar comentario">
</form>

<h2>Comentarios:</h2>
<ul>
    <?php
    foreach($comentarios as $comentario){
        echo"<li>".$comentario."</li>";
    }
    ?>
</ul>

</body>
</html>