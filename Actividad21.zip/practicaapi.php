<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Practica consumo API</h1>

    <?php
    $end_point="https://jsonplaceholder.typicode.com/photos";
    $data=file_get_contents($end_point);//datos en bruto
    //var_dump($data);
    $data_json = json_decode($data, true);//lee como matriz - datos en json
    //var_dump($data_json);
    //$usuarios=$data_json['users'];
    foreach($data_json as $item) {
        //var_dump($item);
        echo('<div class="card" style="width: 18rem;">');
        echo('<img src="'.$item["thumbnailUrl"].'" class="card-img-top" alt="...">');
        echo('<div class="card-body">');
        echo('<h5 class="card-title">'.$item["title"].'</h5>');
        echo('<a href="'.$item["url"].'" class="btn btn-primary">Ampliar foto</a>');
        echo('</div></div>');
    
     }//cierra bucle
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>