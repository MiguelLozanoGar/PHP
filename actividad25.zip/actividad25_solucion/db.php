<?php

$conn=new PDO("pgsql:host=localhost;port=5432;dbname=postgres","postgres","curso");
//var_dump($conn);