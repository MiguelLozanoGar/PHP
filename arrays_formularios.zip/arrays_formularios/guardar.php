<?php
$nombre=$_POST["nombre"];
$unidades=$_POST["unidades"];
echo("<p>Tu nombre ".$nombre." ha sido guardado</p>");
echo("<p>Las unidades ".$unidades." han sido guardadas</p>");