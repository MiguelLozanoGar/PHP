<?php
echo("<h2>Recibir datos</h2>");
$nombre=$_POST["nombre"];
$unidades=$_POST["unidades"];
echo($nombre);
echo("<hr>");
echo($unidades);