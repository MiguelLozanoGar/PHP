<?php

interface iRequisitos{
    //es obligatorio implmentar estos métodos en su clase
public function combatir(); //declarar métodos pero SIN implementar
public function ganar_perder();
public function pasar_nivel();

}