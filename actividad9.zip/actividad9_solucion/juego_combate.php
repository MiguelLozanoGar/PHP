<?php
require_once('juego_padre.php');
class JuegoCombate extends Juego{

    public function __construct(){
        echo("<p>Juego combate inicado</p>");
    }

}