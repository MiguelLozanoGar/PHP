<?php
require_once('requisitos.php');
class Juego implements irequisitos{

    public function combatir(){
        echo("<p>Iniciamos el combate/reto</p>");
    }
    public function ganar_perder(){
        echo("<p>este método dice quién gana</p>"); 
    }
    public function pasar_nivel(){
        echo("<p>Me dices cómo paso de nivel</p>");
    }

}//cierra clase Padre