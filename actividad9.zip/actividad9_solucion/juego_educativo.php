<?php
require_once('juego_padre.php');
class JuegoEducativo extends Juego{

    public function __construct(){
        echo("<p>Juego Educativo inicado</p>");
    }

    //override - sobreescritura
    public function combatir(){
        echo("<p>Iniciamos el test de preguntas</p>");
    }

}