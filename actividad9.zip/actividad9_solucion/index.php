<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Juego</h2>
    <?php
    require_once('juego_educativo.php');
    require_once('juego_combate.php');
    $educativo=new JuegoEducativo();
    $educativo->combatir();
    $combate=new JuegoCombate();
    $combate->combatir();

    $combate->ganar_perder();
    $educativo->ganar_perder();

   


    ?>
</body>
</html>