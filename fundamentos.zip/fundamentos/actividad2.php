<?php
echo("<h2>Ejemplos con arrays</h2>");

$ciudades=[
    "madrid"=>150,
    "sevilla"=>175,
    "malaga"=>147,
];
echo($ciudades["sevilla"]);
unset($ciudades["sevilla"]);
//echo("listado de array ".array_values($ciudades));
echo("<p>".$ciudades["madrid"]."</p>");
echo("<p>".$ciudades["malaga"]."</p>");

$colores=[
    "primario"=>"red",
    "secundario"=>"green",
    "claro"=>"orange",
    "oscuro"=>"black"

];
echo("<p style='color:yellow'>Un texto de ejemplo</p>");
echo("<p style='color:$colores[primario]' >Un texto de ejemplo</p>");
?>