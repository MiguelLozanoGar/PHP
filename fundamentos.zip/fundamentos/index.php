<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>fundamentos php</h2>
    <a href="https://www.php.net/manual/es/">documentacion php</a>
    <?php
    echo("<p>funciona PHP</p>");//esto es un comentario de linea
    /*esto es
    un comentario
    de bloque*/
//Tipos primitivos
    $unidades=15;
    $precio=9.95;
    $descuento=TRUE;
    $mensaje="Muchas gracias por su compra";
    if ($descuento)
    $total=$unidades*$precio*0.9;
    else
    $total=$unidades*$precio;
    
    echo("el total es " .$total);
    echo($mensaje); 

    //Arrays
    echo("<h3>Arrays</h3>");
    $ciudades=["madrid","sevilla","valencia"];
    echo($ciudades[1]);

    echo("<h4>Arrays con clave</h4>");
    $ventas=[
        "juan"=>1950.95,
        "maria"=>147.25,
        "laura"=>1541.25,
        "luis"=>1478.25
    ];
    echo($ventas["luis"]);
    ?>
    <a href="actividad1.php">Solucion act1</a>
    <a href="actividad2.php">Solucion act2</a>

</body>
</html>