<?php
$nombre=$_POST["nombre"];
echo $nombre;
?>