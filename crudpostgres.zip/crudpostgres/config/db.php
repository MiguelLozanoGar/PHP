<?php
$connection_string="host='localhost' port='5432' dbname='postgres' user='postgres' password='curso'";
//$connection_string="host='localhost',port='5432',dbname='postgres',user='postgres',password='curso'";
$conn=pg_connect($connection_string);
//var_dump($conn);