<?php
require_once('../config/db.php');
$consulta="DELETE FROM public.usuarios WHERE id=".$_POST['codigo'].";";
$resultado=pg_query($conn,$consulta);
header('location:consultar.php');
//var_dump($resultado);