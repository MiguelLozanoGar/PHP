<?php
require_once('../config/db.php');

$nombre=$_POST['nombre'];
$precio=$_POST['precio'];
$fecha=$_POST['fecha'];
$acepto=isset($_POST['acepto']);

$acepto_ok=($acepto)?'True':'False';

$consulta="INSERT INTO public.usuarios (nombre,precio,fecha,acepto) 
VALUES('".$nombre."',".$precio.",'".$fecha."',".$acepto_ok.");";
//VALUES(?,?,?,?)";
$resultado=pg_query($conn,$consulta);
var_dump($resultado);