<?php

require_once('../config/db.php');
$consulta="SELECT * from public.usuarios;";
$resultado=pg_query($conn,$consulta);
//var_dump($resultado);
echo("<table border='1'>");
echo("<tr>");
echo("<td>id</td>");
echo("<td>nombre</td>");
echo("<td>precio</td>");
echo("<td>fecha</td>");
echo("<td>acepto</td>");
echo("</tr>");
while($row=pg_fetch_object($resultado)){
    echo("<tr>");
    echo("<td>".$row->id."</td>");
    echo("<td>".$row->nombre."</td>");
    echo("<td>".$row->precio."</td>");
    echo("<td>".$row->fecha."</td>");
    echo("<td>".$row->acepto."</td>");
    echo("</tr>");
}
echo("</table>");
