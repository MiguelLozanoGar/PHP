CREATE TABLE public.usuarios
(
    id serial NOT NULL,
    nombre character VARYING(100),
    precio numeric(6, 2),
    fecha date,
    acepto boolean,
    PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.usuarios
    OWNER to postgres;
	
INSERT INTO public.usuarios (nombre,precio,fecha,acepto) VALUES('juan',20.95,'2023-05-19',False);
SELECT * from public.usuarios;