<?php

$conn = new PDO("mysql:host=localhost;dbname=basesesiones", "root", "");
//var_dump($conn);